from flask import Flask, request, jsonify, render_template
import mysql.connector
from flask_cors import CORS
from rich.markup import render

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Configure MySQL connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Jainashu58@",
    database="hotel_tour_db"
)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/tour_data', methods=['GET'])
def get_tour_data():
    cursor = db.cursor(dictionary=True)
    
    # Fetch hotels data
    cursor.execute("SELECT name, description, image_url FROM hotels")
    hotels = cursor.fetchall()
    
    # Fetch attractions data
    cursor.execute("SELECT name, description, image_url FROM attractions")
    attractions = cursor.fetchall()
    
    cursor.close()
    
    return jsonify({
        'hotels': hotels,
        'attractions': attractions
    })

@app.route('/api/contact', methods=['POST'])
def post_contact_message():
    data = request.form
    name = data.get('name')
    email = data.get('email')
    message = data.get('message')
    
    cursor = db.cursor()
    query = "INSERT INTO messages (name, email, message) VALUES (%s, %s, %s)"
    cursor.execute(query, (name, email, message))
    db.commit()
    cursor.close()
    
    return 'Message sent successfully!', 200

if __name__ == '__main__':
    app.run(debug=True)
