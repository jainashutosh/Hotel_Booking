-- Create the database
CREATE DATABASE hotel_tour_db;

-- Use the database
USE hotel_tour_db;

-- Create the hotels table
CREATE TABLE hotels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    location VARCHAR(100),
    description TEXT
);

-- Create the tours table
CREATE TABLE tours (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hotel_id INT,
    tour_data TEXT,
    FOREIGN KEY (hotel_id) REFERENCES hotels(id)
);

-- Insert sample data into the hotels table
INSERT INTO hotels (name, location, description) VALUES 
('Hotel Sunshine', 'Miami, FL', 'A luxurious hotel in the heart of Miami with stunning views of the ocean.'),
('Mountain Retreat', 'Denver, CO', 'A serene mountain retreat offering a peaceful getaway.'),
('City Central Hotel', 'New York, NY', 'Located in the bustling city center, perfect for business travelers.'),
('Beachside Resort', 'Los Angeles, CA', 'A beautiful resort located right on the beach.'),
('Countryside Inn', 'Austin, TX', 'A charming inn located in the peaceful countryside.'),
('Lakeview Hotel', 'Chicago, IL', 'A modern hotel with stunning views of the lake.'),
('Desert Oasis', 'Phoenix, AZ', 'A relaxing oasis in the middle of the desert.'),
('Historic Hotel', 'Boston, MA', 'A historic hotel with rich history and elegant decor.'),
('Luxury Palace', 'Las Vegas, NV', 'An opulent palace offering luxurious accommodations and entertainment.'),
('Island Escape', 'Honolulu, HI', 'A tropical escape on a beautiful island.');

-- Insert sample data into the tours table
INSERT INTO tours (hotel_id, tour_data) VALUES 
(1, '360-degree view of the oceanfront rooms, pool area, and dining facilities.'),
(2, 'Virtual tour of the mountain view rooms, hiking trails, and spa facilities.'),
(3, 'Tour of the modern rooms, business center, and rooftop bar.'),
(4, 'Beachfront rooms, water sports facilities, and seaside dining areas.'),
(5, 'Countryside view rooms, garden, and local farm tour.'),
(6, 'Lakeview rooms, fitness center, and rooftop lounge.'),
(7, 'Desert view rooms, pool area, and wellness center.'),
(8, 'Historic rooms, grand ballroom, and on-site museum.'),
(9, 'Luxury suites, casino, and exclusive entertainment venues.'),
(10, 'Island view rooms, beach activities, and tropical garden tour.');